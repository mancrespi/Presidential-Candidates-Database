mysql -u root -p < PCDdrop.sql
