mysql -u root -p < PCDtables.sql
