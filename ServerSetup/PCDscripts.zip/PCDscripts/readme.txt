createDatabase --> creates database 'PCD_Database' to root account and creates tables
dropDatabase --> drops 'PCD_Databse' from root account 
