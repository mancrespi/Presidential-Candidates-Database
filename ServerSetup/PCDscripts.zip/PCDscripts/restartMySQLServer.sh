mysql.server restart
