mysql.server start
