mysql.server stop
